import { useMutation, useQueryClient } from "@tanstack/react-query";

import type { ApiAxiosError } from "@/src/services/http.client";
import { createWorkoutSessionForDay } from "@/src/services/workout/daySessions.service";
import { buildGymCheckSessionFromRoutine } from "@/src/utils/gymCheck/buildGymCheckSession";
import type { DayKey } from "@/src/utils/routines/plan";

export function useCreateGymCheckSession() {
    const qc = useQueryClient();

    return useMutation<
        unknown,
        ApiAxiosError,
        { date: string; routine: unknown; weekKey: string; dayKey: DayKey }
    >({
        mutationFn: async ({ date, routine, weekKey, dayKey }) => {
            const built = buildGymCheckSessionFromRoutine({
                routine,
                weekKey,
                dayKey,
                includeOnlyDone: true,
            });

            if (!built.ok) {
                const err = new Error(built.reason) as any;
                err.status = 400;
                throw err;
            }

            return createWorkoutSessionForDay(date, built.body);
        },
        onSuccess: async (_data, vars) => {
            // refresh Days + DaySummary views
            await Promise.allSettled([
                qc.invalidateQueries({ queryKey: ["workoutDay", vars.date] }),
                qc.invalidateQueries({ queryKey: ["daySummary", vars.date] }),
                qc.invalidateQueries({ queryKey: ["routineWeek", vars.weekKey] }),
            ]);
        },
    });
}